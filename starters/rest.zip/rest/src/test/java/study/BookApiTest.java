package study;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest @AutoConfigureMockMvc
class BookApiTest{
 @Autowired MockMvc mvc;@Autowired BookRepository books;
 @BeforeEach void clean(){books.deleteAll();}
 @Test void createsAndRetrievesPersistedBook()throws Exception{mvc.perform(post("/books").contentType("application/json").content("{\"title\":\"Java\"}")).andExpect(status().isCreated()).andExpect(jsonPath("$.title").value("Java"));Book b=books.findAll().get(0);mvc.perform(get("/books/"+b.getId())).andExpect(status().isOk()).andExpect(jsonPath("$.title").value("Java"));assertEquals(1,books.count());}
 @Test void rejectsBlankWithoutSaving()throws Exception{mvc.perform(post("/books").contentType("application/json").content("{\"title\":\" \"}")).andExpect(status().isBadRequest());assertEquals(0,books.count());}
 @Test void unknownIdIs404()throws Exception{mvc.perform(get("/books/999999")).andExpect(status().isNotFound());}
 @Test void invalidJsonIs400()throws Exception{mvc.perform(post("/books").contentType("application/json").content("{")).andExpect(status().isBadRequest());assertEquals(0,books.count());}
 @Test void listReflectsDatabase()throws Exception{books.save(new Book("JVM"));mvc.perform(get("/books")).andExpect(status().isOk()).andExpect(jsonPath("$[0].title").value("JVM"));}
}
