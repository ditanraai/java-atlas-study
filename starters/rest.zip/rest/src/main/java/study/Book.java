package study;
import jakarta.persistence.*;
@Entity
public class Book{
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String title;
 protected Book(){}
 public Book(String title){if(title==null||title.isBlank())throw new IllegalArgumentException("Title required");this.title=title.trim();}
 public Long getId(){return id;} public String getTitle(){return title;}
}
