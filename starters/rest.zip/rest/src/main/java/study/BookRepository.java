package study;
public interface BookRepository extends org.springframework.data.jpa.repository.JpaRepository<Book,Long>{}
