package study;
import java.util.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
@RestController @RequestMapping("/books")
public class BookController{
 private final BookRepository books;
 public BookController(BookRepository books){this.books=books;}
 public record CreateBook(String title){} // final records introduced in 16; project targets 17+
 public record BookView(Long id,String title){}
 private static BookView view(Book b){return new BookView(b.getId(),b.getTitle());}
 @GetMapping public List<BookView> all(){return books.findAll().stream().map(BookController::view).toList();}
 @GetMapping("/{id}") public BookView one(@PathVariable Long id){return view(books.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Book not found")));}
 @PostMapping public ResponseEntity<BookView> create(@RequestBody CreateBook input){try{Book b=books.save(new Book(input.title()));return ResponseEntity.created(java.net.URI.create("/books/"+b.getId())).body(view(b));}catch(IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());}}
}
