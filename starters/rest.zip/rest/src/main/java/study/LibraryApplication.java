package study;
@org.springframework.boot.autoconfigure.SpringBootApplication
public class LibraryApplication{public static void main(String[]args){org.springframework.boot.SpringApplication.run(LibraryApplication.class,args);}}
