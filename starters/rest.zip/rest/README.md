# Java Atlas: rest

Java 17+. No preview features.

```sh
mvn test
mvn spring-boot:run
```

The first milestone is implemented. Continue the remaining website milestones as exercises.

The disposable H2 database is recreated on startup. Add durable storage, schema migrations and an application authorization design before real deployment.
