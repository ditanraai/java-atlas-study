# Java Atlas: inventory

Java 11+. No preview features.

```sh
mvn test
mvn package
java -cp target/classes study.Inventory
```

The first milestone is implemented. Continue the remaining website milestones as exercises.

State is in memory until you implement persistence.
