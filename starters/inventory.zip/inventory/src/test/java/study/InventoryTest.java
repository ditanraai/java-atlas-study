package study;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class InventoryTest {
 @Test void reservesWithoutOverdraft(){Inventory i=new Inventory();i.register("A",3);assertTrue(i.reserve("A",2));assertFalse(i.reserve("A",2));assertEquals(1,i.quantity("A"));}
 @Test void validatesAndAdds(){Inventory i=new Inventory();assertThrows(IllegalArgumentException.class,()->i.register("",1));assertThrows(IllegalArgumentException.class,()->i.register("A",-1));i.register("A",0);i.add("A",2);assertEquals(2,i.quantity("A"));assertThrows(IllegalArgumentException.class,()->i.register("A",1));assertThrows(IllegalArgumentException.class,()->i.add("A",-1));}
 @Test void snapshotIsSeparate(){Inventory i=new Inventory();i.register("A",1);var copy=i.snapshot();i.add("A",1);assertEquals(1,copy.get("A"));assertThrows(UnsupportedOperationException.class,()->copy.put("B",1));}
 @Test void concurrentReservationsPreserveInvariant()throws Exception{Inventory i=new Inventory();i.register("A",1);java.util.concurrent.atomic.AtomicInteger successes=new java.util.concurrent.atomic.AtomicInteger();Runnable r=()->{if(i.reserve("A",1))successes.incrementAndGet();};Thread a=new Thread(r),b=new Thread(r);a.start();b.start();a.join();b.join();assertEquals(1,successes.get());assertEquals(0,i.quantity("A"));}
}
