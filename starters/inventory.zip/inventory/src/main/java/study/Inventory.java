package study;
import java.util.*;
public final class Inventory {
 private final Map<String,Integer> stock=new LinkedHashMap<>();
 private static void valid(String sku,int n){if(sku==null||sku.trim().isEmpty()||n<0)throw new IllegalArgumentException("Valid SKU and nonnegative quantity required");}
 public synchronized void register(String sku,int n){valid(sku,n);if(stock.containsKey(sku))throw new IllegalArgumentException("Duplicate SKU");stock.put(sku,n);}
 public synchronized void add(String sku,int n){valid(sku,n);stock.put(sku,Math.addExact(quantity(sku),n));}
 public synchronized int quantity(String sku){Integer n=stock.get(sku);if(n==null)throw new NoSuchElementException("Unknown SKU");return n;}
 public synchronized boolean reserve(String sku,int n){valid(sku,n);int available=quantity(sku);if(n>available)return false;stock.put(sku,available-n);return true;}
 public synchronized Map<String,Integer> snapshot(){return Collections.unmodifiableMap(new LinkedHashMap<>(stock));}
 public static void main(String[] args){Inventory i=new Inventory();i.register("JAVA",5);i.reserve("JAVA",2);System.out.println(i.snapshot());}
}
