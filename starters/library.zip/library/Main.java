import java.util.*;
public class Main {
 static final class Book {
  final String id,title; private boolean available=true;
  Book(String id,String title){if(id==null||id.trim().isEmpty()||title==null||title.trim().isEmpty())throw new IllegalArgumentException("ID and title required");this.id=id;this.title=title;}
  boolean available(){return available;}
  void borrow(){if(!available)throw new IllegalStateException("Already borrowed");available=false;}
  void giveBack(){if(available)throw new IllegalStateException("No active loan");available=true;}
 }
 static final class Library {
  private final Map<String,Book> books=new LinkedHashMap<>();
  void add(Book b){Objects.requireNonNull(b);if(books.putIfAbsent(b.id,b)!=null)throw new IllegalArgumentException("Duplicate ID");}
  Book find(String id){Book b=books.get(id);if(b==null)throw new NoSuchElementException("Unknown book");return b;}
 }
 static void check(boolean value){if(!value)throw new AssertionError("Failed");}
 static void expect(Class<? extends Throwable> type,Runnable r){try{r.run();}catch(Throwable t){if(type.isInstance(t))return;throw new AssertionError(t);}throw new AssertionError("Expected "+type);}
 static void tests(){Library l=new Library();Book b=new Book("1","Java");l.add(b);l.find("1").borrow();check(!b.available());expect(IllegalStateException.class,b::borrow);b.giveBack();check(b.available());b.borrow();check(!b.available());expect(IllegalArgumentException.class,()->l.add(new Book("1","duplicate")));expect(NoSuchElementException.class,()->l.find("missing"));expect(IllegalArgumentException.class,()->new Book("","Java"));System.out.println("Library checks passed");}
 public static void main(String[] args){if(args.length>0&&args[0].equals("--test")){tests();return;}Library l=new Library();l.add(new Book("1","Java"));Book b=l.find("1");b.borrow();System.out.println(b.title+" available: "+b.available());b.giveBack();System.out.println(b.title+" available: "+b.available());}
}
