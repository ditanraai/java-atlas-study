# Java Atlas: library

Java 8+. No preview features.

```sh
javac Main.java
java Main --test
java Main
```

The first milestone is implemented. Continue the remaining website milestones as exercises.

State is in memory until you implement persistence.
